# Campaign Report

- Total events: 2
- Matched events: 0
- Delivery rate: 0.00%

## Latency
- Mean: 0.0s
- Median: 0.0s
- P90: 0.0s
- P95: 0.0s
